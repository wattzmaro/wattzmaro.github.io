﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AtsExCsTemplate.MapPlugin
{
    internal class TimeDraw
    {
        //0~9.:を読み込む（pと同じ）
        //Native.VehicleState.Timeから
    }
}
